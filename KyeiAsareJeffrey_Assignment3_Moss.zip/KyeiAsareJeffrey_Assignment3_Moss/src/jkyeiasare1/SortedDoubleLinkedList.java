package jkyeiasare1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Comparator;

import org.junit.jupiter.api.Test;

public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T>{
	private Comparator<T> comparator;
	
	public SortedDoubleLinkedList(Comparator<T> comparator) {
		super();
		this.comparator = comparator;
	}

	public SortedDoubleLinkedList<T> add(T element) {
		Node newNode = new Node(element);

		if (head == null || comparator.compare(element, head.data) <= 0) {
			newNode.next = head;
			head = newNode;

			if (size == 0) {
				tail = newNode;
			}
		} else {
			Node current = head;
			Node previous = null;

			while (current.next != null
					&& comparator.compare(element, current.data) >= 0) {

				if (!(comparator.compare(element, current.next.data) >= 0)) {
					break;
				} else {
					previous = current;
					current = current.next;
				}
			}

			if (comparator.compare(element, current.data) >= 0) {

				if (size == 1 || current == tail) {

					current.next = newNode;
					tail = newNode;
				} else {

					newNode.next = current.next;
					current.next = newNode;
				}
			}
		}
		size++;
		return this;
	}

	public SortedDoubleLinkedList<T> remove(T targetData) {
		return (SortedDoubleLinkedList<T>) remove(targetData, comparator);
	}

	public void addToEnd(T data) throws UnsupportedOperationException{
		if (this instanceof SortedDoubleLinkedList) {
			throw new UnsupportedOperationException(
					"Invalid operation for sorted list");
		}

	
	}

	public void addToFront(T data) throws UnsupportedOperationException{
		if (this instanceof SortedDoubleLinkedList) {
			throw new UnsupportedOperationException(
					"Invalid operation for sorted list");
		}

	
	}
	
	
}
