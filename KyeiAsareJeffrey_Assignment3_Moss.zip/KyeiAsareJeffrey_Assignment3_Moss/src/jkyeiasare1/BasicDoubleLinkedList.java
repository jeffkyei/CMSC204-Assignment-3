package jkyeiasare1;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

public class BasicDoubleLinkedList<T> implements Iterable<T>{
	
	
	//Node class
	protected class Node {
		protected T data;
		protected Node next;
		protected Node prev;

		//Node constructor
		protected Node(T data) {
			this.data = data;
			next = null;
			prev = null;
		}
	}
	
	//intialize head, tail, and size
		protected Node head;
		protected Node tail;
		protected int size;
		
	//Constructor for BasicDoubleLinkedList
	public BasicDoubleLinkedList() {
		head = null;
		tail = null;
		size = 0;
	}

	//Get size, return size
	public int getSize() {
		return size;
	}
	
	//Add node to end of list
	public void addToEnd(T data) {
		Node newNode = new Node(data); //create node

		if (tail == null) { //tail = null means list is empty
			head = newNode;
			tail = newNode;
		} 
		else {
			tail.next = newNode; //add 1 more to the end & change tail
			tail = newNode;
		}
		size++;
	}
	//Add node to front of list
	public void addToFront(T data) {
		Node newNode = new Node(data);  //create node

		if (head == null) { //tail = null means list is empty
			
			head = newNode;
			tail = newNode;
		} 
		else {
			newNode.next = head; //add 1 more to the front & change head
			head = newNode;
		}
		size++;
	}
	
	//return first node 
	public T getFirst() {
		if (head == null) { //if head is null return null
			return null;
		} 
		else {  //else return head data
			return head.data;
		}
	}
	
	//return last node
	public T getLast() {
		if (tail == null) { //if tail is null return null
			return null;
		} 
		else {  //else return head data
			return tail.data;
		}
	}
	
	//return and remove first element
	public T retrieveFirstElement() {
		if (head == null) { //if head is null return null
			return null;
		}
		else {
			Node ogHead = head; //ogHead is to be returned
			
			if (size > 1) { //remove current head
				head = head.next;
			}
			else {
				head = null;
				tail = null; //necessary?
			}
			
			size--; //size = size -1 since head is gone
			return ogHead.data;
		}
		
	}
	
	public T retrieveLastElement() {
		if (tail == null) { //if tail is null return null
			return null;
		}
		else {
			Node current = head;
			Node ogTail = tail; //ogTail is to be returned
			
			if(size > 1 ) {
				while (current.next != tail) {
					current = current.next; //keep going until we get to the 2nd to last element
				}
				current.next = null; //delete tail

				// update tail
				tail = current; //new tail is 2nd to last element
			}
			else {
				head = null;
				tail = null; //necessary
				
			}
			size--; //size = size -1 since tail is gone
			return ogTail.data;
		}
	}
	
	public BasicDoubleLinkedList<T> remove(T targetData, Comparator<T> comparator) {
		if (head == null) { //if list is empty then there is nothing to return so return null
			return null;
		} else {
			Node current = head;
			Node previous = null; 

			while (current.next != null) {  //while loop continues while not on last node
				if (comparator.compare(current.data, targetData) == 0) { //compare checks if they equal, if true it is 0
					if (current == head) {
						head = head.next;
						previous = null; // 
						current = current.next;

						size--;
					} else {
						previous.next = previous.next.next;
						current = previous.next;
						size--;
					}
				} else {
					previous = current;
					current = current.next;
				}
			} 

			// if statemment to check if curr.next equals null
			if (size == 1
					&& comparator.compare(current.data, targetData) == 0) {
				// check if there is only one node and it equals target, should be 0
				head = null;
				tail = null;
				size--;
			} else if (current == tail
					&& comparator.compare(current.data, targetData) == 0) {
				// check if target is tail, should be 0
				previous.next = null;
				tail = previous;

				size--;
			}
		}
		return this;
	}
	public java.util.ArrayList<T> toArrayList(){
		ArrayList jeff = new ArrayList();
		Node current = head;

		while (current != null) { //keep going until list is empty
			jeff.add(current.data);    //add current data
			current = current.next;
		}

		return jeff;
	}
	
	@Override
	public java.util.ListIterator<T> iterator() {
		class DoubleLinkedListIterator implements ListIterator<T> { //create class for iterator
			Node current; //intialize current node to head
			Node previous;
			
			//construcotr
			public DoubleLinkedListIterator() {
				current = head;
				previous = null;
			}
			
			//hasNext, true or false
			public boolean hasNext() {
				return current != null;
			}
			
			//return next.data
			public T next() throws NoSuchElementException{
				if(!hasNext()) {
					throw new NoSuchElementException();
				}
				else {
					T currentData = current.data;
	
					previous = current;
					current = current.next;
					return currentData;
				}
			}
			//hasprevious, true or false
			@Override
			public boolean hasPrevious() {
				return previous != null;
			}
			//return previous data
			@Override
			public T previous() throws NoSuchElementException {
				if(!hasPrevious()) {
					throw new NoSuchElementException();
				}
				else {
					T prevData = previous.data;
					
					return prevData;
				}
			}

			@Override
			public int nextIndex() throws UnsupportedOperationException{
				throw new UnsupportedOperationException();
			}


			@Override
			public int previousIndex() throws UnsupportedOperationException {
				throw new UnsupportedOperationException();
			}

			@Override
			public void remove() throws UnsupportedOperationException {
				throw new UnsupportedOperationException();
			}

			@Override
			public void set(Object e) throws UnsupportedOperationException {
				throw new UnsupportedOperationException();
			}

			@Override
			public void add(Object e) throws UnsupportedOperationException {
				throw new UnsupportedOperationException();
			}
		}
		return new DoubleLinkedListIterator();
	}
}
	
