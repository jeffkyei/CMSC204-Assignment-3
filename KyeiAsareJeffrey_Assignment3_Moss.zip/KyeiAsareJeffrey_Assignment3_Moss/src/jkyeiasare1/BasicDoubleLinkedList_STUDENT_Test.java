package jkyeiasare1;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Comparator;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


class BasicDoubleLinkedList_STUDENT_Test {

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

//	@Test
//	void test() {
//		fail("Not yet implemented");
//		
//	}
	
	@Test
	public void addToFront() {
		BasicDoubleLinkedList<String> basicList = new BasicDoubleLinkedList<String>();
		basicList.addToFront("Jeff");
		basicList.addToFront("Peter");
		basicList.addToFront("Kyei");
		
		ArrayList<String> arr = new ArrayList<>();
		arr.add("Kyei");
		arr.add("Peter");
		arr.add("Jeff");
		
		assertEquals(arr, basicList.toArrayList());
	}
	
	@Test
	public void addToEnd() {
		BasicDoubleLinkedList<String> basicList = new BasicDoubleLinkedList<String>();
		basicList.addToEnd("Jeff");
		basicList.addToEnd("Peter");
		basicList.addToEnd("Kyei");
		
		ArrayList<String> arr = new ArrayList<>();
		arr.add("Jeff");
		arr.add("Peter");
		arr.add("Kyei");
		
		assertEquals(arr, basicList.toArrayList());
	}
	
	@Test
	public void getFirstLast() {
		BasicDoubleLinkedList<String> basicList = new BasicDoubleLinkedList<String>();
		basicList.addToEnd("Jeff");
		basicList.addToFront("Peter");
		basicList.addToEnd("Kyei");

		assertEquals("Peter", basicList.getFirst());
		assertEquals("Kyei", basicList.getLast());
		
		BasicDoubleLinkedList<String> basicList2 = new BasicDoubleLinkedList<String>();
		basicList2.addToEnd("Jeff");
		
		assertEquals("Jeff", basicList2.getFirst());
		assertEquals("Jeff", basicList2.getLast());
		
		BasicDoubleLinkedList<Integer> intList = new BasicDoubleLinkedList<Integer>();
		intList.addToEnd(2);
		intList.addToFront(1);
		intList.addToEnd(3);
		
		assertTrue(intList.getFirst() == 1);
		assertTrue(intList.getLast() == 3);
	}
	
	@Test
	public void retrieveFirstLast() {
		BasicDoubleLinkedList<String> basicList = new BasicDoubleLinkedList<String>();
		basicList.addToEnd("Jeff");
		basicList.addToEnd("Peter");
		basicList.addToEnd("Kyei");
		
		ArrayList<String> arr = new ArrayList<>();
		arr.add("Jeff");
		arr.add("Peter");
		arr.add("Kyei");
		
		assertEquals(basicList.getFirst(), basicList.retrieveFirstElement());
		assertEquals(basicList.getLast(), basicList.retrieveLastElement());
		
		BasicDoubleLinkedList<Integer> intList = new BasicDoubleLinkedList<Integer>();
		intList.addToFront(1);
		intList.addToEnd(2);
		intList.addToEnd(3);
		
		assertEquals(intList.getFirst(), intList.retrieveFirstElement());
		assertEquals(intList.getLast(), intList.retrieveLastElement());
		
		
		BasicDoubleLinkedList<Integer> intList2 = new BasicDoubleLinkedList<Integer>();
				
		assertEquals(null , intList2.retrieveFirstElement());
		assertEquals(null , intList2.retrieveLastElement());

		BasicDoubleLinkedList<Integer> intList3 = new BasicDoubleLinkedList<Integer>();
		intList3.addToEnd(2);
				
		assertEquals(2, intList3.retrieveLastElement());
	}
	
	@Test
	public void removeBasicTest() {
		BasicDoubleLinkedList<String> basicList1 = new BasicDoubleLinkedList<String>();
		basicList1.addToEnd("Jeff");
		basicList1.addToEnd("Peter");
		basicList1.addToEnd("Kyei");
		basicList1.addToEnd("Peter");
		
		ArrayList<String> arr = new ArrayList<>();
		arr.add("Peter");
		arr.add("Kyei");
		arr.add("Peter");
		
		
		
		basicList1.remove("Jeff", String.CASE_INSENSITIVE_ORDER);		
		assertEquals(arr, basicList1.toArrayList());
	}
	@Test
	public void iteratorTest() {
		BasicDoubleLinkedList<String> basicList = new BasicDoubleLinkedList<String>();
		basicList.addToEnd("Jeff");
		basicList.addToFront("Peter");
		basicList.addToEnd("Kyei");
		
		ArrayList listContents = new ArrayList<>();
		
		for (String entry : basicList) {
			listContents.add(entry);
		}
		
		assertEquals(listContents, basicList.toArrayList());
	}
	@Test
	public void ArrayListTest() {
		BasicDoubleLinkedList<String> basicList = new BasicDoubleLinkedList<String>();
		basicList.addToEnd("Jeff");
		basicList.addToEnd("Peter");
		basicList.addToEnd("Kyei");
		
		ArrayList<String> arr = new ArrayList();
		arr.add("Jeff");
		arr.add("Peter");
		arr.add("Kyei");
		
		assertEquals(arr, basicList.toArrayList());
	}
	
	
	

}
