package jkyeiasare1;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Comparator;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SortedDoubleLinkedList_STUDENT_Test {

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	public void add() {
		SortedDoubleLinkedList<String> sortedList = new SortedDoubleLinkedList<String>(String.CASE_INSENSITIVE_ORDER);
		sortedList.add("Jeff");
		sortedList.add("Peter");
		sortedList.add("Kyei");
				
		ArrayList<String> arr = new ArrayList<>();
		arr.add("Jeff");
		arr.add("Kyei");
		arr.add("Peter");
		
		assertEquals(arr, sortedList.toArrayList());
		
		Comparator<Integer> intComparator = new Comparator<Integer>() {
	        @Override
	        public int compare(Integer o1, Integer o2) {
	        	return o1.compareTo(o2);
	        }
	    };
	    
	    SortedDoubleLinkedList<Integer> intList = new SortedDoubleLinkedList<Integer>(intComparator);
		intList.add(2);
		intList.add(1);
		intList.add(4);
		intList.add(0);
		intList.add(3);
		
		ArrayList<Integer> arr1 = new ArrayList<>();
		
		arr1.add(0);
		arr1.add(1);
		arr1.add(2);
		arr1.add(3);
		arr1.add(4);
		assertEquals(arr1, intList.toArrayList());
	}
	
	@Test
	public void removeSorted() {
		SortedDoubleLinkedList<String> sortedList = new SortedDoubleLinkedList<String>(String.CASE_INSENSITIVE_ORDER);
		sortedList.add("Jeff");
		sortedList.add("Peter");
		sortedList.add("Kyei");
		sortedList.remove("Peter");
		
		
		ArrayList<String> arr = new ArrayList<>();
		arr.add("Jeff");
		arr.add("Kyei");
		
		assertEquals(arr, sortedList.toArrayList());
		
		Comparator<Integer> intComparator = new Comparator<Integer>() {
	        @Override
	        public int compare(Integer o1, Integer o2) {
	        	return o1.compareTo(o2);
	        }
	    };
	    
	    SortedDoubleLinkedList<Integer> intList = new SortedDoubleLinkedList<Integer>(intComparator);
		intList.add(2);
		intList.add(1);
		intList.add(3);
		intList.remove(2);
		
		ArrayList<Integer> arr2 = new ArrayList<>();
		arr2.add(1);
		arr2.add(3);
		assertEquals(arr2 , intList.toArrayList());
		
	}
	
	@Test
	public void addFrontEndSorted() {
		UnsupportedOperationException thrown1 = assertThrows(UnsupportedOperationException.class, () -> {
			SortedDoubleLinkedList<String> sortedList = new SortedDoubleLinkedList<String>(String.CASE_INSENSITIVE_ORDER);
			sortedList.addToEnd("Red");
			sortedList.addToFront("Orange");
		});

	  assertEquals("Invalid operation for sorted list", thrown1.getMessage());
	  
	  Comparator<Integer> intComparator = new Comparator<Integer>() {
	        @Override
	        public int compare(Integer o1, Integer o2) {
	        	return o1.compareTo(o2);
	        }
	    };
	  
	  UnsupportedOperationException thrown2 = assertThrows(UnsupportedOperationException.class, () -> {
			SortedDoubleLinkedList<Integer> intList = new SortedDoubleLinkedList<Integer>(intComparator);
			intList.addToEnd(2);
			intList.addToFront(3);
		});

	  assertEquals("Invalid operation for sorted list", thrown2.getMessage());
	}
	
	
	
}
